# LOL 매칭 및 커뮤니티 프로젝트
Riot 개발사 Leage of Legends 게임의 플레이어간 대전 매칭 및 커뮤니티 웹 사이트 프로젝트 입니다.

## 기술 스택
- JAVA(JDK >= 11)
- JSP/Servlet
- MySQL
- Mybatis
- Spring boot Framework(Gradle)


